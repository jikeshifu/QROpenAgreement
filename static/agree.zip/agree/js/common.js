
			
			/*点击接受时可提交*/
			$("#tongyi").click(function(){
				if($("#tongyi")[0].checked==true){
					$("#tijiao")[0].disabled=false;
					$("#tijiao").css('cursor','pointer');
					$("#tijiao").addClass("but");
				}
			});
			/*点击不接受时不可提交*/
			$("#notongyi").click(function(){
				if($("#notongyi")[0].checked==true){
					$("#tijiao")[0].disabled=true;
					$("#tijiao").css('cursor','');
					$("#tijiao").removeClass("but");
					
				}
			});
                        $("#tijiao").click(function(){
                            var lock_id = $("#lock_id").val();
                            alert(lock_id);
                            return false;
                        });
